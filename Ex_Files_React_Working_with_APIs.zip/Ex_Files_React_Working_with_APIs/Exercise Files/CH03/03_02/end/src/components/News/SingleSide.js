import React from 'react';

const SingleSide = ({item}) => (
  <div>
    <div className="divider"></div>
    <div className="section">
      <h5>Section 1</h5>
      <p>stuff</p>
    </div>
  </div>
);

export default SingleSide;
