import React from 'react';

const NewSingle = ({item}) => (
  <li>
    <p>{item.title}</p>
  </li>
);

export default NewSingle;
